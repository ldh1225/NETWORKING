package com.example.networking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
